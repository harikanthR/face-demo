package com.anonymous.demoapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.identy.face.AS;
import com.identy.face.Attempt;
import com.identy.face.FaceMatch;          // <-- if red, press Alt+Enter and import the correct FaceMatch class
import com.identy.face.IdentyError;
import com.identy.face.IdentyFaceLocalMatch;   // if red: needs the matcher module in build.gradle, then Alt+Enter
import com.identy.face.IdentyFaceSdk;
import com.identy.face.IdentyResponse;
import com.identy.face.IdentyResponseListener;
import com.identy.face.InitializationListener;

import java.util.HashSet;

public class MainActivity extends AppCompatActivity {
    public static final String license = "5252-com.anonymous.demoapp-30-06-2026(1).lic";

    private enum Mode { ENROLL, VERIFY }
    private Mode currentMode = Mode.ENROLL;

    private final ActivityResultLauncher<String> cameraPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    startFlow(currentMode);
                } else {
                    Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnEnroll = findViewById(R.id.btnEnroll);
        Button btnVerify = findViewById(R.id.btnVerify);

        btnEnroll.setOnClickListener(v -> onButtonPressed(Mode.ENROLL));
        btnVerify.setOnClickListener(v -> onButtonPressed(Mode.VERIFY));
    }

    private void onButtonPressed(Mode mode) {
        currentMode = mode;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startFlow(mode);
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA);
        }
    }

    // On-device matcher (from Identy docs: new IdentyFaceLocalMatch())
    private FaceMatch getFaceMatch() {
        return new IdentyFaceLocalMatch();
    }

    private void startFlow(Mode mode) {
        try {
            IdentyFaceSdk.newInstance(this, license, new InitializationListener<IdentyFaceSdk>() {
                @Override
                public void onInit(IdentyFaceSdk sdkInstance) {
                    try {

                        sdkInstance.displayResult(true);
                        sdkInstance.setASSecLevel(AS.BALANCED_VERY_HIGH);
                        sdkInstance.enableAssistedMode();
                        if (sdkInstance == null) return;

                        if (mode == Mode.ENROLL) {
                            sdkInstance.enroll(getFaceMatch());   // captures + saves the face in the KeyStore
                        } else {
                            sdkInstance.verify(getFaceMatch());   // captures + compares with the enrolled face
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onInitFailed() {
                    Log.e("IDENTY", "Init failed");
                    runOnUiThread(() ->
                            Toast.makeText(MainActivity.this, "Initialization failed ...", Toast.LENGTH_LONG).show());
                }
            }, new IdentyResponseListener() {
                @Override
                public void onAttempt(int i, Attempt attempt) { }

                @Override
                public void onResponse(IdentyResponse identyResponse, HashSet hashSet) {
                    runOnUiThread(() -> {
                        if (currentMode == Mode.ENROLL) {
                            Toast.makeText(MainActivity.this, "Enrollment successful!", Toast.LENGTH_SHORT).show();
                        } else {
                            // TODO: read the match result from identyResponse (the docs say the
                            // response holds "verification metadata"). Ctrl+click IdentyResponse
                            // to see which getters it has.
                            Toast.makeText(MainActivity.this, "Verification done", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

                @Override
                public void onErrorResponse(IdentyError identyError, HashSet hashSet) {
                    String msg = identyError != null ? String.valueOf(identyError.getError()) : "Unknown";
                    Log.e("IDENTY", "Error response: " + msg);
                    runOnUiThread(() ->
                            Toast.makeText(MainActivity.this, "Error: " + msg, Toast.LENGTH_LONG).show());
                }
            }, false);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "SDK Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}